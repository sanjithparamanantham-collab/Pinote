# 📝 MeetNote - Floating Meeting Notepad

A lightweight browser extension that adds a floating, draggable notepad inside Google Meet and Zoom. No bots, no AI, no sign-up — just fast, clean notes.

---

## 🚀 How to Install (Chrome / Edge)

1. Download and unzip this folder
2. Open Chrome and go to: `chrome://extensions`
   - For Edge: `edge://extensions`
3. Turn ON **Developer Mode** (top right toggle)
4. Click **"Load unpacked"**
5. Select this folder (`meeting-notes-extension`)
6. Done! Open any Google Meet or Zoom link ✅

---

## 🎯 Features

- 📌 Floating notepad pinned inside Google Meet & Zoom
- 💾 Auto-saves notes per meeting URL
- 📑 Multiple tabs per meeting (General, Actions, Ideas, etc.)
- 🖱️ Draggable & resizable notepad
- 📋 Copy notes to clipboard
- ⬇️ Export notes as .txt file
- ⌨️ Keyboard shortcut: **Alt + N** to toggle

---

## 📁 File Structure

```
meeting-notes-extension/
├── manifest.json     ← Extension configuration
├── content.js        ← Main logic (injected into Meet/Zoom)
├── styles.css        ← Notepad UI styles
├── popup.html        ← Extension popup
├── popup.js          ← Popup logic
└── icons/            ← Extension icons
```

---

## 🌐 Publishing to Firefox (Free)

1. Go to: https://addons.mozilla.org/developers/
2. Create a free account
3. Click "Submit a New Add-on"
4. Zip this folder and upload
5. Fill in description and screenshots
6. Submit for review (1–3 days)

## 🌐 Publishing to Edge (Free)

1. Go to: https://partner.microsoft.com/dashboard/microsoftedge/
2. Create a developer account (free)
3. Submit the extension zip
4. Review takes 1–7 days

---

## 💰 Monetization Ideas

- **Free tier**: 3 meetings, basic features
- **Pro tier**: Unlimited meetings, PDF export, note history
- Use **Lemon Squeezy** to handle payments and licensing

---

## 🛠️ Customization Tips

- Edit `styles.css` to change colors/fonts
- Edit `content.js` to add new features
- Increase tab limit in `content.js` (search `tabs.length >= 5`)

---

Made with ❤️ using plain HTML, CSS & JavaScript

#!/usr/bin/env python3
"""Generate simple placeholder icons for MeetNote extension"""

import struct
import zlib
import os

def create_png(size, color=(49, 130, 206)):
    """Create a simple colored square PNG"""
    width = height = size
    
    def pack_chunk(chunk_type, data):
        c = chunk_type + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    
    # PNG signature
    sig = b'\x89PNG\r\n\x1a\n'
    
    # IHDR
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    ihdr = pack_chunk(b'IHDR', ihdr_data)
    
    # Build image data - gradient circle effect
    raw_rows = []
    r, g, b = color
    for y in range(height):
        row = b'\x00'  # filter type none
        for x in range(width):
            # Circle with rounded look
            cx = x - width / 2
            cy = y - height / 2
            dist = (cx**2 + cy**2) ** 0.5
            radius = width * 0.42
            
            if dist <= radius:
                # Inner gradient
                factor = 1 - (dist / radius) * 0.3
                pr = min(255, int(r * factor + 20))
                pg = min(255, int(g * factor))
                pb = min(255, int(b * factor + 10))
                row += bytes([pr, pg, pb])
            else:
                row += bytes([26, 26, 46])  # background color
        raw_rows.append(row)
    
    raw_data = b''.join(raw_rows)
    compressed = zlib.compress(raw_data, 9)
    idat = pack_chunk(b'IDAT', compressed)
    iend = pack_chunk(b'IEND', b'')
    
    return sig + ihdr + idat + iend

os.makedirs('icons', exist_ok=True)

for size in [16, 48, 128]:
    png_data = create_png(size, color=(49, 130, 206))
    with open(f'icons/icon{size}.png', 'wb') as f:
        f.write(png_data)
    print(f'Created icons/icon{size}.png')

print('Icons created successfully!')

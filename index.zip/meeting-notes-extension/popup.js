// MeetNote - Popup Script

const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const recentList = document.getElementById('recent-list');

// Check if current tab is a meeting
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = tabs[0]?.url || '';
  const isMeet = url.includes('meet.google.com');
  const isZoom = url.includes('zoom.us');

  if (isMeet || isZoom) {
    statusDot.classList.add('active');
    statusText.textContent = isMeet ? 'Active: Google Meet' : 'Active: Zoom';
  } else {
    statusText.textContent = 'Open a Meet or Zoom to take notes';
  }
});

// Load recent meeting notes
chrome.storage.local.get(null, (items) => {
  const meetingKeys = Object.keys(items).filter(k => k.startsWith('meetnote_'));

  if (meetingKeys.length === 0) {
    return;
  }

  recentList.innerHTML = '';

  // Show last 4 meetings
  const recent = meetingKeys.slice(-4).reverse();

  recent.forEach(key => {
    const data = items[key];
    const urlEncoded = key.replace('meetnote_', '');
    const url = decodeURIComponent(urlEncoded);

    const totalWords = (data.tabs || []).reduce((sum, tab) => {
      const w = tab.content?.trim().split(/\s+/).filter(Boolean).length || 0;
      return sum + w;
    }, 0);

    if (totalWords === 0) return;

    const isMeet = url.includes('meet.google.com');
    const icon = isMeet ? '🎥' : '💻';

    const shortUrl = url.replace('https://', '').replace('http://', '');

    const item = document.createElement('div');
    item.className = 'recent-item';
    item.innerHTML = `
      <span class="recent-icon">${icon}</span>
      <div class="recent-info">
        <div class="recent-url">${shortUrl}</div>
        <div class="recent-meta">${totalWords} words · ${data.tabs?.length || 1} tab(s)</div>
      </div>
    `;
    recentList.appendChild(item);
  });

  if (recentList.children.length === 0) {
    recentList.innerHTML = '<div class="empty-state">No notes saved yet</div>';
  }
});

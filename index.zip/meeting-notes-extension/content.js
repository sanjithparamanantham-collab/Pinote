// Pinote — Full Featured Content Script
// Free | Pro | Business — all features included, gated by PLAN variable

(function () {
  if (document.getElementById('pn-container')) return;

  // ── Change this to 'pro' or 'business' to unlock features ──
  const PLAN = 'free'; // 'free' | 'pro' | 'business'

  const meetingKey = 'pn_' + encodeURIComponent(location.href.split('?')[0]);
  let tabs = [], activeTab = 0, isDragging = false;
  let dragOffsetX = 0, dragOffsetY = 0, saveTimeout = null;
  let theme = 'dark', searchOpen = false, templatesOpen = false, brandOpen = false;
  let brandInfo = { company: '', website: '', email: '', footer: '' };

  const TEMPLATES = [
    { icon: '📋', label: 'Standup',     sub: 'Daily sync',      text: '✅ Yesterday:\n\n🔄 Today:\n\n⛔ Blockers:\n' },
    { icon: '🤝', label: '1-on-1',      sub: 'Manager meeting', text: '💬 Discussion points:\n\n📌 Action items:\n\n⭐ Wins:\n\n🎯 Goals:\n' },
    { icon: '🚀', label: 'Sprint',      sub: 'Planning session', text: '🎯 Sprint goal:\n\n📝 Stories:\n\n⚠️ Risks:\n\n✅ Done criteria:\n' },
    { icon: '👥', label: 'Client call', sub: 'Client meeting',  text: '🏢 Client:\n\n📋 Agenda:\n\n💡 Key points:\n\n📌 Next steps:\n\n📅 Follow-up date:\n' },
    { icon: '🧠', label: 'Brainstorm',  sub: 'Ideas session',   text: '💡 Ideas:\n\n✅ Best options:\n\n❌ Ruled out:\n\n📌 Next steps:\n' },
    { icon: '📊', label: 'Review',      sub: 'Retrospective',   text: '✅ What went well:\n\n❌ What to improve:\n\n💡 Suggestions:\n\n🎯 Action items:\n' },
  ];

  // ── Build UI ──────────────────────────────────────────────────────────────
  const container = document.createElement('div');
  container.id = 'pn-container';
  container.setAttribute('data-pn-theme', 'dark');
  container.innerHTML = `
    <div id="pn-header">
      <div id="pn-header-left">
        <span id="pn-logo">📌</span>
        <span id="pn-title">Pinote</span>
        <span id="pn-plan-badge">${PLAN.toUpperCase()}</span>
      </div>
      <div id="pn-header-actions">
        <button class="pn-btn" id="pn-theme-btn" title="Toggle theme">🌙</button>
        <button class="pn-btn" id="pn-search-btn" title="Search past notes (Pro)">🔍</button>
        <button class="pn-btn" id="pn-template-btn" title="Templates (Pro)">📄</button>
        <button class="pn-btn" id="pn-brand-btn" title="Company branding (Business)">🏢</button>
        <button class="pn-btn" id="pn-minimize-btn" title="Minimize">─</button>
        <button class="pn-btn" id="pn-close-btn" title="Hide">✕</button>
      </div>
    </div>

    <div id="pn-search-panel">
      <input id="pn-search-input" placeholder="Search all past meeting notes..." />
      <div id="pn-search-results"></div>
    </div>

    <div id="pn-templates-panel">
      <div id="pn-templates-title">Choose a template</div>
      <div class="pn-template-grid" id="pn-template-grid"></div>
    </div>

    <div id="pn-brand-panel">
      <label>Company name</label>
      <input id="pn-brand-company" placeholder="Acme Technologies Pvt. Ltd." />
      <label>Website</label>
      <input id="pn-brand-website" placeholder="www.acme.com" />
      <label>Email</label>
      <input id="pn-brand-email" placeholder="contact@acme.com" />
      <label>Footer text</label>
      <input id="pn-brand-footer" placeholder="Confidential — Internal Use Only" />
      <button id="pn-save-brand-btn">Save Branding</button>
    </div>

    <div id="pn-tabs">
      <div class="pn-tab active" data-tab="0">📋 General</div>
      <div class="pn-tab-add" id="pn-add-tab" title="Add tab">+</div>
    </div>

    <div id="pn-body">
      <textarea id="pn-textarea" placeholder="Start typing your meeting notes here...

• Action items
• Key decisions
• Follow-ups

Notes are saved automatically ✓"></textarea>
      <div id="pn-wordcount">0 words</div>
      <div id="pn-saved">✓ Saved</div>
    </div>

    <div id="pn-footer">
      <button class="pn-action-btn" id="pn-copy-btn">📋 Copy</button>
      <button class="pn-action-btn" id="pn-txt-btn">⬇ TXT</button>
      <button class="pn-action-btn" id="pn-pdf-btn">📄 PDF</button>
      <button class="pn-action-btn" id="pn-clear-btn">🗑 Clear</button>
    </div>
  `;

  const toggleBtn = document.createElement('button');
  toggleBtn.id = 'pn-toggle-btn';
  toggleBtn.title = 'Open Pinote (Alt+N)';
  toggleBtn.innerHTML = '📌';

  const toast = document.createElement('div');
  toast.id = 'pn-toast';

  document.body.appendChild(container);
  document.body.appendChild(toggleBtn);
  document.body.appendChild(toast);

  // ── Refs ──────────────────────────────────────────────────────────────────
  const textarea    = document.getElementById('pn-textarea');
  const tabsBar     = document.getElementById('pn-tabs');
  const wordcount   = document.getElementById('pn-wordcount');
  const savedEl     = document.getElementById('pn-saved');
  const searchPanel = document.getElementById('pn-search-panel');
  const searchInput = document.getElementById('pn-search-input');
  const searchRes   = document.getElementById('pn-search-results');
  const tmplPanel   = document.getElementById('pn-templates-panel');
  const tmplGrid    = document.getElementById('pn-template-grid');
  const brandPanel  = document.getElementById('pn-brand-panel');

  // ── Plan gate ─────────────────────────────────────────────────────────────
  function requirePlan(feature, minPlan = 'pro') {
    const order = ['free', 'pro', 'business'];
    if (order.indexOf(PLAN) >= order.indexOf(minPlan)) return true;
    showToast(`🔒 ${feature} requires ${minPlan.toUpperCase()} — upgrade to unlock!`);
    return false;
  }

  // ── Storage ───────────────────────────────────────────────────────────────
  function loadData(cb) {
    chrome.storage.local.get([meetingKey, 'pn_theme', 'pn_brand'], (r) => {
      const data = r[meetingKey] || { tabs: [{ name: '📋 General', content: '' }], activeTab: 0 };
      if (r.pn_theme) theme = r.pn_theme;
      if (r.pn_brand) brandInfo = r.pn_brand;
      cb(data);
    });
  }

  function saveData() {
    tabs[activeTab].content = textarea.value;
    chrome.storage.local.set({ [meetingKey]: { tabs, activeTab } });
    savedEl.classList.add('show');
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => savedEl.classList.remove('show'), 1500);
  }

  // ── Theme ─────────────────────────────────────────────────────────────────
  function applyTheme() {
    container.setAttribute('data-pn-theme', theme);
    document.getElementById('pn-theme-btn').textContent = theme === 'dark' ? '🌙' : '☀️';
    chrome.storage.local.set({ pn_theme: theme });
  }

  document.getElementById('pn-theme-btn').addEventListener('click', () => {
    theme = theme === 'dark' ? 'light' : 'dark';
    applyTheme();
  });

  // ── Tabs ──────────────────────────────────────────────────────────────────
  function renderTabs() {
    tabsBar.querySelectorAll('.pn-tab').forEach(el => el.remove());
    tabs.forEach((tab, i) => {
      const el = document.createElement('div');
      el.className = 'pn-tab' + (i === activeTab ? ' active' : '');
      el.dataset.tab = i;
      el.textContent = tab.name;
      el.addEventListener('click', () => switchTab(i));
      el.addEventListener('dblclick', () => {
        const n = prompt('Rename tab:', tab.name);
        if (n && n.trim()) { tabs[i].name = n.trim(); renderTabs(); saveData(); }
      });
      tabsBar.insertBefore(el, document.getElementById('pn-add-tab'));
    });
  }

  function switchTab(i) {
    tabs[activeTab].content = textarea.value;
    activeTab = i;
    textarea.value = tabs[activeTab].content;
    updateWordCount(); renderTabs();
  }

  document.getElementById('pn-add-tab').addEventListener('click', () => {
    const maxTabs = PLAN === 'free' ? 2 : 5;
    if (tabs.length >= maxTabs) {
      showToast(PLAN === 'free' ? '🔒 More tabs available on Pro!' : 'Max 5 tabs allowed');
      return;
    }
    tabs[activeTab].content = textarea.value;
    const names = ['📌 Actions', '💡 Ideas', '❓ Questions', '🔁 Follow-ups'];
    tabs.push({ name: names[tabs.length - 1] || `Tab ${tabs.length + 1}`, content: '' });
    activeTab = tabs.length - 1;
    textarea.value = '';
    renderTabs(); textarea.focus(); saveData();
  });

  // ── Word count ────────────────────────────────────────────────────────────
  function updateWordCount() {
    const t = textarea.value.trim();
    const w = t ? t.split(/\s+/).length : 0;
    wordcount.textContent = `${w} words · ${textarea.value.length} chars`;
  }

  // ── Toast ─────────────────────────────────────────────────────────────────
  let toastTimeout;
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toast.classList.remove('show'), 2500);
  }

  // ── Panel toggle helper ───────────────────────────────────────────────────
  function closeAllPanels() {
    searchOpen = templatesOpen = brandOpen = false;
    searchPanel.classList.remove('show');
    tmplPanel.classList.remove('show');
    brandPanel.classList.remove('show');
  }

  // ── Search ────────────────────────────────────────────────────────────────
  document.getElementById('pn-search-btn').addEventListener('click', () => {
    if (!requirePlan('Search notes')) return;
    const willOpen = !searchOpen;
    closeAllPanels();
    if (willOpen) {
      searchOpen = true;
      searchPanel.classList.add('show');
      searchInput.focus();
      renderSearchResults('');
    }
  });

  searchInput.addEventListener('input', () => renderSearchResults(searchInput.value.trim()));

  function renderSearchResults(query) {
    chrome.storage.local.get(null, (all) => {
      const keys = Object.keys(all).filter(k => k.startsWith('pn_') && !['pn_theme','pn_brand','pn_session_count'].includes(k));
      if (!keys.length) {
        searchRes.innerHTML = '<div id="pn-search-empty">No past meetings found yet.</div>';
        return;
      }
      const results = [];
      keys.forEach(key => {
        const data = all[key];
        if (!data || !data.tabs) return;
        const url = decodeURIComponent(key.replace('pn_', ''));
        data.tabs.forEach((tab, tabIdx) => {
          if (!tab.content) return;
          if (!query || tab.content.toLowerCase().includes(query.toLowerCase())) {
            const idx = query ? tab.content.toLowerCase().indexOf(query.toLowerCase()) : 0;
            const raw = tab.content.substring(Math.max(0, idx - 20), idx + 60).replace(/\n/g, ' ');
            const snippet = query
              ? raw.replace(new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), m => `<mark>${m}</mark>`)
              : raw;
            results.push({ url, tabName: tab.name, snippet, key, tabIdx });
          }
        });
      });

      if (!results.length) {
        searchRes.innerHTML = `<div id="pn-search-empty">${query ? 'No results found.' : 'Type to search your notes.'}</div>`;
        return;
      }

      searchRes.innerHTML = '';
      results.slice(0, 8).forEach(r => {
        const el = document.createElement('div');
        el.className = 'pn-search-result';
        const shortUrl = r.url.replace(/https?:\/\//, '').substring(0, 40);
        el.innerHTML = `<div class="pn-search-result-url">🔗 ${shortUrl} · ${r.tabName}</div>
          <div class="pn-search-result-snippet">${r.snippet}…</div>`;
        el.addEventListener('click', () => {
          chrome.storage.local.get([r.key], (d) => {
            const data = d[r.key];
            if (!data) return;
            tabs = data.tabs; activeTab = r.tabIdx;
            renderTabs();
            textarea.value = tabs[activeTab].content;
            updateWordCount();
            closeAllPanels();
            showToast('✓ Loaded meeting notes');
          });
        });
        searchRes.appendChild(el);
      });
    });
  }

  // ── Templates ─────────────────────────────────────────────────────────────
  TEMPLATES.forEach(t => {
    const btn = document.createElement('button');
    btn.className = 'pn-template-btn';
    btn.innerHTML = `${t.icon} ${t.label}<span>${t.sub}</span>`;
    btn.addEventListener('click', () => {
      if (!requirePlan('Templates')) return;
      if (textarea.value.trim() && !confirm('Replace current content with template?')) return;
      textarea.value = t.text;
      updateWordCount(); saveData();
      closeAllPanels();
      showToast(`✓ ${t.label} template applied`);
    });
    tmplGrid.appendChild(btn);
  });

  document.getElementById('pn-template-btn').addEventListener('click', () => {
    if (!requirePlan('Templates')) return;
    const willOpen = !templatesOpen;
    closeAllPanels();
    if (willOpen) { templatesOpen = true; tmplPanel.classList.add('show'); }
  });

  // ── Branding ──────────────────────────────────────────────────────────────
  document.getElementById('pn-brand-btn').addEventListener('click', () => {
    if (!requirePlan('Company branding', 'business')) return;
    const willOpen = !brandOpen;
    closeAllPanels();
    if (willOpen) {
      brandOpen = true; brandPanel.classList.add('show');
      document.getElementById('pn-brand-company').value = brandInfo.company || '';
      document.getElementById('pn-brand-website').value = brandInfo.website || '';
      document.getElementById('pn-brand-email').value   = brandInfo.email   || '';
      document.getElementById('pn-brand-footer').value  = brandInfo.footer  || '';
    }
  });

  document.getElementById('pn-save-brand-btn').addEventListener('click', () => {
    brandInfo = {
      company: document.getElementById('pn-brand-company').value.trim(),
      website: document.getElementById('pn-brand-website').value.trim(),
      email:   document.getElementById('pn-brand-email').value.trim(),
      footer:  document.getElementById('pn-brand-footer').value.trim(),
    };
    chrome.storage.local.set({ pn_brand: brandInfo });
    closeAllPanels();
    showToast('✓ Company branding saved!');
  });

  // ── Copy ──────────────────────────────────────────────────────────────────
  document.getElementById('pn-copy-btn').addEventListener('click', () => {
    if (!textarea.value.trim()) { showToast('Nothing to copy!'); return; }
    navigator.clipboard.writeText(textarea.value).then(() => showToast('✓ Copied to clipboard!'));
  });

  // ── TXT Export (Pro) ──────────────────────────────────────────────────────
  document.getElementById('pn-txt-btn').addEventListener('click', () => {
    if (!requirePlan('TXT export')) return;
    if (!textarea.value.trim()) { showToast('Nothing to export!'); return; }
    const now = new Date();
    const tabName = tabs[activeTab].name.replace(/[^\w\s]/g, '').trim() || 'notes';
    let content = '';
    if (PLAN === 'business' && brandInfo.company) {
      content += `${brandInfo.company}\n`;
      if (brandInfo.website || brandInfo.email)
        content += [brandInfo.website, brandInfo.email].filter(Boolean).join('  |  ') + '\n';
      content += '═'.repeat(44) + '\n\n';
    }
    content += `Pinote Export\nTab: ${tabs[activeTab].name}\nDate: ${now.toLocaleString()}\nURL: ${location.href}\n${'─'.repeat(40)}\n\n`;
    content += textarea.value;
    if (PLAN === 'business' && brandInfo.footer)
      content += `\n\n${'─'.repeat(40)}\n${brandInfo.footer}`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pinote-${tabName}-${now.toISOString().slice(0,10)}.txt`;
    a.click(); URL.revokeObjectURL(url);
    showToast('✓ Exported as TXT!');
  });

  // ── PDF Export (Pro + Branded for Business) ───────────────────────────────
  document.getElementById('pn-pdf-btn').addEventListener('click', () => {
    if (!requirePlan('PDF export')) return;
    if (!textarea.value.trim()) { showToast('Nothing to export!'); return; }
    const now = new Date();
    const hasBrand = PLAN === 'business' && brandInfo.company;
    const noteContent = textarea.value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Pinote Export</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <style>
      *{margin:0;padding:0;box-sizing:border-box;}
      body{font-family:'Inter',sans-serif;background:#f8fafc;color:#1e293b;padding:40px;}
      .page{background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);}
      .brand-header{background:linear-gradient(135deg,#1a56db,#2563eb);color:white;padding:28px 36px;}
      .brand-name{font-size:24px;font-weight:700;margin-bottom:6px;}
      .brand-meta{font-size:13px;opacity:0.8;margin-bottom:6px;}
      .brand-tag{font-size:11px;opacity:0.5;margin-top:8px;}
      .simple-header{padding:24px 36px 0;display:flex;align-items:center;gap:12px;}
      .simple-pin{font-size:28px;}
      .simple-name{font-size:22px;font-weight:700;color:#1a56db;}
      .meta-bar{display:flex;gap:20px;padding:14px 36px;background:#f1f5f9;font-size:13px;color:#64748b;border-top:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0;}
      .meta-bar strong{color:#1e293b;}
      .content{padding:28px 36px;white-space:pre-wrap;font-size:14px;line-height:1.85;min-height:260px;color:#1e293b;}
      .footer-bar{padding:14px 36px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;font-size:11px;color:#94a3b8;}
      @media print{body{background:white;padding:0;}.page{box-shadow:none;border-radius:0;}}
    </style></head><body><div class="page">`);

    if (hasBrand) {
      win.document.write(`<div class="brand-header">
        <div class="brand-name">${brandInfo.company}</div>
        ${brandInfo.website || brandInfo.email ? `<div class="brand-meta">${[brandInfo.website, brandInfo.email].filter(Boolean).join('  ·  ')}</div>` : ''}
        <div class="brand-tag">Meeting Notes — Powered by Pinote</div>
      </div>`);
    } else {
      win.document.write(`<div class="simple-header">
        <span class="simple-pin">📌</span>
        <span class="simple-name">Pinote</span>
      </div>`);
    }

    win.document.write(`
      <div class="meta-bar">
        <span>📋 <strong>Tab:</strong> ${tabs[activeTab].name}</span>
        <span>📅 <strong>Date:</strong> ${now.toLocaleDateString()}</span>
        <span>⏰ <strong>Time:</strong> ${now.toLocaleTimeString()}</span>
        <span>🔗 <strong>Meeting:</strong> ${location.hostname}</span>
      </div>
      <div class="content">${noteContent}</div>
      <div class="footer-bar">
        <span>${hasBrand && brandInfo.footer ? brandInfo.footer : 'Generated by Pinote'}</span>
        <span>pinote.app</span>
      </div>
    </div>
    <script>window.onload = () => { window.print(); }<\/script>
    </body></html>`);
    win.document.close();
    showToast('✓ PDF ready — print or save as PDF!');
  });

  // ── Clear ─────────────────────────────────────────────────────────────────
  document.getElementById('pn-clear-btn').addEventListener('click', () => {
    if (!textarea.value.trim()) return;
    if (confirm('Clear notes for this tab?')) {
      textarea.value = ''; updateWordCount(); saveData(); showToast('Tab cleared');
    }
  });

  // ── Minimize / Close ──────────────────────────────────────────────────────
  document.getElementById('pn-minimize-btn').addEventListener('click', () => {
    container.classList.toggle('pn-minimized');
    document.getElementById('pn-minimize-btn').textContent =
      container.classList.contains('pn-minimized') ? '□' : '─';
  });

  document.getElementById('pn-close-btn').addEventListener('click', () => {
    container.classList.add('pn-hidden');
    toggleBtn.style.display = 'flex';
  });

  toggleBtn.addEventListener('click', () => {
    container.classList.remove('pn-hidden');
    toggleBtn.style.display = 'none';
    textarea.focus();
  });

  // ── Drag ──────────────────────────────────────────────────────────────────
  const headerEl = document.getElementById('pn-header');
  headerEl.addEventListener('mousedown', (e) => {
    if (e.target.classList.contains('pn-btn')) return;
    isDragging = true;
    const r = container.getBoundingClientRect();
    dragOffsetX = e.clientX - r.left;
    dragOffsetY = e.clientY - r.top;
    container.style.transition = 'none';
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const x = e.clientX - dragOffsetX, y = e.clientY - dragOffsetY;
    container.style.left   = Math.max(0, Math.min(x, window.innerWidth  - container.offsetWidth))  + 'px';
    container.style.top    = Math.max(0, Math.min(y, window.innerHeight - container.offsetHeight)) + 'px';
    container.style.right  = 'auto';
    container.style.bottom = 'auto';
  });
  document.addEventListener('mouseup', () => {
    isDragging = false;
    document.body.style.userSelect = '';
  });

  // ── Auto-save ─────────────────────────────────────────────────────────────
  textarea.addEventListener('input', () => {
    updateWordCount();
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(saveData, 800);
  });

  // ── Alt+N shortcut ────────────────────────────────────────────────────────
  document.addEventListener('keydown', (e) => {
    if (e.altKey && e.key === 'n') {
      e.preventDefault();
      if (container.classList.contains('pn-hidden')) {
        container.classList.remove('pn-hidden');
        toggleBtn.style.display = 'none';
        textarea.focus();
      } else {
        container.classList.add('pn-hidden');
        toggleBtn.style.display = 'flex';
      }
    }
  });

  // ── Free plan session limiter ─────────────────────────────────────────────
  function checkFreeLimit() {
    if (PLAN !== 'free') return;
    chrome.storage.local.get(['pn_session_count'], (r) => {
      const count = (r.pn_session_count || 0) + 1;
      chrome.storage.local.set({ pn_session_count: count });
      if (count > 3) {
        const lock = document.createElement('div');
        lock.className = 'pn-pro-lock';
        lock.innerHTML = `
          <div class="pn-pro-lock-icon">🔒</div>
          <div class="pn-pro-lock-text">Free limit reached</div>
          <div class="pn-pro-lock-sub">You've used your 3 free sessions.<br/>Upgrade to Pro for unlimited meetings.</div>
          <button class="pn-upgrade-btn" onclick="window.open('https://pinote.app/#pricing','_blank')">⭐ Upgrade to Pro — ₹99/mo</button>
        `;
        document.getElementById('pn-body').appendChild(lock);
      }
    });
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  loadData((data) => {
    tabs = data.tabs || [{ name: '📋 General', content: '' }];
    activeTab = Math.min(data.activeTab || 0, tabs.length - 1);
    renderTabs();
    textarea.value = tabs[activeTab].content || '';
    updateWordCount();
    applyTheme();
    checkFreeLimit();
  });

  toggleBtn.style.display = 'none';
})();
